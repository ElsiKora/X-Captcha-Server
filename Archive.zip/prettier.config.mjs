export default {
	arrowParens: "always",
	bracketSameLine: true,
	bracketSpacing: true,
	jsxSingleQuote: false,
	printWidth: 480,
	proseWrap: "never",
	semi: true,
	singleQuote: false,
	tabWidth: 2,
	trailingComma: "all",
	useTabs: true,
};
