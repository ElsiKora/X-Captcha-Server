import type { Challenge } from "../entity/challenge.entity";

export interface IChallengeVerifyProperties {
	challenge: Challenge;
}
