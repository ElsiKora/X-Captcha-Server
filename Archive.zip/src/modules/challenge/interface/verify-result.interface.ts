export interface IChallengeVerifyResult {
	isSolved: boolean;
}
