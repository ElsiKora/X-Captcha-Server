export interface IChallengeSolveResult {
	token: string;
}
