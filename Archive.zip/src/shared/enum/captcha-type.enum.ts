export enum ECaptchaType {
	CLICK = "click",
	POW = "pow",
}
