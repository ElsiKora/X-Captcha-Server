export interface IEventEmitterResponse {
	error?: unknown;
	isSuccess: boolean;
}
